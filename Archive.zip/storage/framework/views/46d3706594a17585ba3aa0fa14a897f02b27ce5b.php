<?php $__env->startSection('content'); ?>
<style type="text/css">
.full-container {
    min-height: calc(100% - 15.2rem);
}
</style>
<div class="container full-container mt-3">
    <?php if(session('status')): ?>
    <div class="alert alert-success" role="alert">
        <?php echo e(session('status')); ?>

    </div>
    <?php endif; ?>
    <div class="row mx-0 h-50">
        <div class="col-lg-4 col-md-4 col-12 mx-auto d-flex justify-content-center align-items-center flex-column">
            <div class="text-center h4 mb-5"><b>RESET PASSWORD</b></div>
            <form class="w-100" method="POST" action="<?php echo e(route('password.email')); ?>">
                <?php echo e(csrf_field()); ?>

                <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                    <input id="email" type="email" class="form-control" name="email" placeholder="EMAIL" value="<?php echo e(old('email')); ?>" required autofocus> <?php if($errors->has('email')): ?>
                    <small class="form-text text-muted">
                        <?php echo e($errors->first('email')); ?>

                    </small> <?php endif; ?>
                </div>
                <button type="submit" class="btn btn-blue btn-block btn-lg">Send Password Reset Link</button>
            </form>
        </div>
    </div>
    <!--  <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Reset Password</div>

                <div class="panel-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <form class="form-horizontal" method="POST" action="<?php echo e(route('password.email')); ?>">
                        <?php echo e(csrf_field()); ?>


                        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            <label for="email" class="col-md-4 control-label">E-Mail Address</label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required>

                                <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    Send Password Reset Link
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div> -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>