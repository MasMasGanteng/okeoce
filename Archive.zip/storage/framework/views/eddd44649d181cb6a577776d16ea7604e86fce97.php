<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <!-- call to action -->
        <div class="row mx-md-0">
            <div class="col product-myos-div">
                <a href="javascript:void(0)">
                    <img class="img-fluid" src="image/product-myos-link.png" alt="Make your own sushi" id="make_your_own">
                </a>
            </div>
            <div class="col product-rtos-div">
                <a href="javascript:void(0)">
                    <img class="img-fluid" src="image/product-rtos-link.png" alt="Ready to eat sushi" id="ready_to_eat">
                </a>
            </div>
        </div>
    </div>
    <div class="container">
        <!-- make your own sushi -->
        <?php echo $__env->make('partials.makesushi', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- ready to eat sushi -->
        <?php echo $__env->make('partials.buysushi', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>