<?php $__env->startSection('content'); ?>
    <?php $__currentLoopData = $promo_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="container">
        <img class="d-block w-100" src="uploads/front/banner/<?php echo e($list->url_img_banner); ?>">
        <div class="promo-detail">
            <div class="title">
                <?php echo e($list->title); ?><br>
                Berlaku Hingga<br>
                <?php echo e($list->end_date); ?>

            </div>
            <div class="content">
                Syarat & ketentuan:<br>
                <?php echo e($list->description); ?>

            </div>
            <div class="contact">
                Lokasi & Contact :<br>
                <?php echo e($list->location); ?>

            </div>
        </div>
        <button class="btn btn-blue btn-toggle-promo" id="<?php echo e($list->id); ?>" type="button">DETAIL PROMO</button>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
 <?php $__env->startSection('footer_scripts'); ?>
<script>
    
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>