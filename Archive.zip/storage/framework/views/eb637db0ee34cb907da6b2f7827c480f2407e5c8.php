 <?php $__env->startSection('header_styles'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container full-container">
    <div class="font-blue h5 mt-3 mb-4">
        <b>DETAIL ORDER</b>
    </div>
    <table class="table baiza-table" id="order_table">
        <thead>
            <tr class="header">
                <th scope="col">Nama Barang</th>
                <th scope="col">Jumlah</th>
                <th scope="col">Harga</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $order_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $op): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr style="border-bottom: 2px solid #ddd">
                <td>
                    <?php echo e($op->name); ?>

                    <ul>
                        <li>Essential</li>
                            <ol type="1">
                            <?php $__currentLoopData = $order_ingredient_essential; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $essential): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($op->id_order_detail==$essential->order_detail_ref): ?>
                                    <li><?php echo e($essential->name); ?></li>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ol>
                    </ul>
                    <?php if($op->id==4): ?>
                    <ul>
                        <li>Special</li>
                            <ol type="1">
                            <?php $__currentLoopData = $order_ingredient_special; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $special): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($op->id_order_detail==$special->order_detail_ref): ?>
                                    <li><?php echo e($special->name); ?></li>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ol>
                    </ul>
                    <?php endif; ?>
                    <ul>
                        <li>Sprinkle</li>
                            <ol type="1">
                            <?php $__currentLoopData = $order_ingredient_sprinkle; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sprinkle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($op->id_order_detail==$sprinkle->order_detail_ref): ?>
                                    <li><?php echo e($sprinkle->name); ?></li>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ol>
                    </ul>
                    <ul>
                        <li>House Sauce</li>
                            <ol type="1">
                            <?php $__currentLoopData = $order_ingredient_house_sauce; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $house_sauce): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($op->id_order_detail==$house_sauce->order_detail_ref): ?>
                                    <li><?php echo e($house_sauce->name); ?></li>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ol>
                    </ul>
                </td>
                <td class="jml_product_order"><input class="form-control" id="jml<?php echo e($op->id_order_detail); ?>" type="number" min="1" oninput="calculate(<?php echo e($op->id_order_detail); ?>)" value="1" required></td>
                <td class="price_product_default">
                    <span id="price<?php echo e($op->id_order_detail); ?>"><?php echo e('Rp. '.number_format($op->price,2,",",".")); ?></span>
                    <input id="price_hidden<?php echo e($op->id_order_detail); ?>" type="number" min="1" value="<?php echo e($op->price); ?>" hidden>
                </td>
            </tr>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot>
            <tr class="spasi">
                <th scope="col"></th>
            </tr>
            <tr class="total">
                <th scope="col"></th>
                <th scope="col"><span class="font-blue">Total</span></th>
                <th class="total_order_rp" scope="col">
                    <span id="total"><?php echo e('Rp. '.number_format($price,2,",",".")); ?></span>
                </th>
            </tr>
        </tfoot>
    </table>
    <form id=form>
        <div class="form-row">
           <div class="form-group col-md-4">
                <input type="hidden" class="form-control" name="id" id="id" value="<?php echo e($id); ?>">
                <input type="text" class="form-control" placeholder="NAMA PENERIMA" value="<?php echo e($nama_penerima); ?>">
            </div>
            <div class="form-group col-md-4">
                <input type="number" class="form-control" placeholder="NO HP PENERIMA" value="<?php echo e($phone_number); ?>">
            </div>
            <div class="form-group col-md-4">
                <input type="number" class="form-control" placeholder="KODE POS" value="<?php echo e($kode_pos); ?>">
            </div>
        </div>
        <div class="form-row">
            <div class="form-group col-md-4">
                <select id="select-kode_kota-input" name="select-kode_kota-input" class="form-control select2" size="1" required>
                    <option value>Please select</option>
                    <?php $__currentLoopData = $kode_kota_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($list->kode); ?>" <?php echo $kode_kota==$list->kode ? 'selected':''; ?>><?php echo e($list->nama); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group col-md-4">
                <select id="select-kode_kec-input" name="select-kode_kec-input" class="form-control select2" size="1" required>
                    <option value>Please select</option>
                    <?php $__currentLoopData = $kode_kec_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($list->kode); ?>" <?php echo $kode_kec==$list->kode ? 'selected':''; ?>><?php echo e($list->nama); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group col-md-4">
                <select id="select-kode_kel-input" name="select-kode_kel-input" class="form-control select2" size="1" required>
                    <option value>Please select</option>
                    <?php $__currentLoopData = $kode_kel_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($list->kode); ?>" <?php echo $kode_kel==$list->kode ? 'selected':''; ?>><?php echo e($list->nama); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <div class="form-group">
            <textarea class="form-control" placeholder="ALAMAT" rows="3"><?php echo e($address); ?></textarea>
        </div>
        <div class="text-center mt-5 mb-3">
            <button type="submit" class="btn btn-info btn-lg">Manual Confirmation</button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>  <?php $__env->startSection('footer_scripts'); ?>
<script>
    $(document).ready(function(){
        $('#form').bootstrapValidator().on('success.form.bv', function(e) {
            $('#form').on('submit', function (e) {
                e.preventDefault();
                var form_data = new FormData(this);
                var id = $('#id').val();
                $.ajax({
                    type: 'post',
                    processData: false,
                    contentType: false,
                    "url": "/dashboard/order_pending/create",
                    data: form_data,
                    beforeSend: function (){
                        $("#submit").prop('disabled', true);
                    },
                    success: function () {
                        alert('From Submitted.');
                        window.location.href = "/dashboard/order_in";
                    },
                    error: function (xhr, ajaxOptions, thrownError) {
                        alert(xhr.status);
                        alert(thrownError);
                        $("#submit").prop('disabled', false);
                    }
                });
            });
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>