 <?php $__env->startSection('header_styles'); ?>
<link href="https://cdnjs.cloudflare.com/ajax/libs/jquery.bootstrapvalidator/0.5.2/css/bootstrapValidator.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">
                <?php $__currentLoopData = $banner_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li data-target="#carouselExampleIndicators" data-slide-to="<?php echo e($index); ?>" class="<?php if($index == 0): ?> <?php echo e('active'); ?> <?php endif; ?>"></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ol>
            <div class="carousel-inner">
                <?php $__currentLoopData = $banner_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="carousel-item <?php if($index == 0): ?> <?php echo e('active'); ?> <?php endif; ?>">
                    <img class="d-block w-100" src="uploads/front/banner/<?php echo e($banner->url_img_banner); ?>" alt="<?php echo e($banner->description); ?>">
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <!-- call to action -->
        <div class="row no-gutters mx-auto mt-4" style="max-width: 1233px;">
            <input type="text" id="user" name="user" value="<?php echo e($user); ?>" hidden>
            <div class="col-12 col-md-6 col-lg-6 myos-div">
                <div class="row mx-0 align-items-center">
                    <div class="col-7 pl-0">
                    </div>
                    <div class="col pl-0">
                        <a href="javascript:void(0)">
                            <img class="img-fluid" src="image/myos-link.png" alt="Make your own sushi" id="make_your_own">
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-6 col-lg-6 rtos-div">
                <div class="row mx-0 align-items-center">
                    <div class="col-5 pl-0">
                    </div>
                    <div class="col pl-5">
                        <a href="javascript:void(0)" >
                            <img class="img-fluid" src="image/rtos-link.png" alt="Ready to eat sushi" id="ready_to_eat">
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <!-- make your own sushi -->
        <?php echo $__env->make('partials.makesushi', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- ready to eat sushi -->
        <?php echo $__env->make('partials.buysushi', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>