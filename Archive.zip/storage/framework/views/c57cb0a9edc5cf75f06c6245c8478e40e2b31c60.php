<?php $__env->startSection('content'); ?>
<div class="container full-container flex-div mt-3">
    <div class="col-lg-5 col-md-6 col-12 mx-auto">
        <h4 class="text-center"><b>LOGIN</b></h4>
        <div class="row my-4">
            <div class="col-6">
                <a href="<?php echo e(URL('/redirect')); ?>" class="btn btn-blue btn-lg btn-block">Facebook</a>
            </div>
            <div class="col-6">
                <a href="<?php echo e(URL('/redirect')); ?>" class="btn btn-peach btn-lg btn-block">Google</a>
            </div>
        </div>
        <p class="text-center">or</p>
        <form method="POST" action="<?php echo e(route('login')); ?>">
            <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                <input id="email" type="email" class="form-control" name="email" placeholder="EMAIL" value="<?php echo e(old('email')); ?>" required autofocus>
                <?php if($errors->has('email')): ?>
                <small class="form-text text-muted"><?php echo e($errors->first('email')); ?></small>
                <?php endif; ?>
            </div>
            <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                <input id="password" type="password" class="form-control" name="password" placeholder="PASSWORD" required>
                <?php if($errors->has('password')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('password')); ?></strong>
                </span>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <div class="row no-gutters">
                    <div class="col-6">
                        <div class="custom-control custom-checkbox">
                            <input id="remember_session" type="checkbox" class="custom-control-input" type="checkbox" name="remember" <?php echo e(old( 'remember') ? 'checked' : ''); ?>>
                            <label class="custom-control-label" for="remember_session">Remember Me</label>
                        </div>
                    </div>
                    <div class="col-6 text-right">
                        <a href="<?php echo e(route('password.request')); ?>">Forgot Password?</a>
                    </div>
                </div>
            </div>
            <button type="submit" class="btn btn-blue btn-block btn-lg">LOGIN</button>
        </form>
        <p class="text-center">
            Didn't have an account? <a href="<?php echo e(route('register')); ?>">REGISTER</a>
        </p>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>