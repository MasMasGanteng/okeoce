<div class="login-pop-up">
    <div class="message-box">
        <div class="close-box">
            <button class="btn btn-peach login-overlay">X</button>
        </div>
        <form class="form-horizontal" method="POST" action="<?php echo e(route('login')); ?>">
            <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required autofocus>
                <?php if($errors->has('email')): ?>
                <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
            </div>
            <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                <input id="password" type="password" class="form-control" name="password" required>

                                <?php if($errors->has('password')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
            </div>

            <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <div class="checkbox">
                                    <label>
                                        <input type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>> Remember Me
                                    </label>
                                </div>
                            </div>
                        </div>

            <button type="submit" class="btn btn-blue">MASUK</button>
            <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                                    Forgot Your Password?
                                </a>
        </form>
        <!-- <a href="/register" class="register-overlay">REGISTER</a> -->
    </div>
</div>