<div id="order_ready_to_eat" hidden>
    <div class="text-center m-5">
        <img class="img-fluid" src="image/rtos-title.png">
    </div>
    <div class="row no-gutters justify-content-md-center">
        <div class="col col-lg-11">
            <div class="row mx-0">
                <?php $__currentLoopData = $product_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col col-md-6 col-lg-6 p-2">
                    <div class="sushi-list">
                        <div class="sl-img">
                            <img class="img-fluid" src="uploads/product/product/<?php echo e($list->url_img_product); ?>">
                        </div>
                        <div class="sl-text">
                            <div class="title">
                                <?php echo e($list->name); ?>

                            </div>
                            <div class="content">
                                <?php echo e($list->description); ?>

                            </div>
                            <!-- <input type="text" id="id_product_buysushi<?php echo e($list->id); ?>" name="id_product_buysushi" value="<?php echo e($list->id); ?>" hidden> -->
                            <button id="<?php echo e($list->id); ?>" class="btn btn-blue" onclick="buysushi($(this));return false;">ADD TO CART</button>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>