<footer class="footer">
    <ul class="list-inline">
        <li class="list-inline-item"><a href="/terms">TERM & CONDITION</a></li>
        <li class="list-inline-item"><a href="/refund_policy">REFUND POLICY</a></li>
        <li class="list-inline-item"><a href="/faq">FAQ</a></li>
        <li class="list-inline-item"><a href="/contact">CONTACT US</a></li>
    </ul>
    &copy; COPYRIGHT BAIZA SUSHI 2018. ALL RIGHT RESERVED
</footer>
