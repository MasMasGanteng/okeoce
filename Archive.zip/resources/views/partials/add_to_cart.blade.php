<div class="cart-pop-up">
    <div class="message-box">
    	<div class="col-9 mx-auto">
    		<div class="h6 font-blue mb-4">
    			<b>YOUR ITEM HAS ADDED ON YOUR CART</b>
    		</div>
    		<button type="button" class="btn btn-blue btn-block cart-overlay">CONTINUE SHOPPING</button>
    		<!-- <button type="submit" class="btn btn-blue btn-block">CHECKOUT</button> -->
    		<a href="/detail_order" class="btn btn-blue btn-block">CHECKOUT</a>
    	</div>        
    </div>
</div>